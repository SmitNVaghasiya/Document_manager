import 'priority_model.dart';

class Document {
  final String name;
  final String category;
  final String filePath;
  final DateTime uploadedAt;
  final String? user;
  final DateTime? expiryDate;
  final String? groupId;
  final DocumentPriority priority;

  Document({
    required this.name,
    required this.category,
    required this.filePath,
    required this.uploadedAt,
    this.user,
    this.expiryDate,
    this.groupId,
    DocumentPriority? priority,
  }) : priority = priority ?? DocumentPriority();

  Document copyWith({
    String? name,
    String? category,
    String? filePath,
    DateTime? uploadedAt,
    String? user,
    DateTime? expiryDate,
    String? groupId,
    DocumentPriority? priority,
  }) {
    return Document(
      name: name ?? this.name,
      category: category ?? this.category,
      filePath: filePath ?? this.filePath,
      uploadedAt: uploadedAt ?? this.uploadedAt,
      user: user ?? this.user,
      expiryDate: expiryDate ?? this.expiryDate,
      groupId: groupId ?? this.groupId,
      priority: priority ?? this.priority,
    );
  }

  bool get isExpired =>
      expiryDate != null && expiryDate!.isBefore(DateTime.now());

  bool get isExpiringSoon =>
      expiryDate != null &&
      expiryDate!.isAfter(DateTime.now()) &&
      expiryDate!.isBefore(DateTime.now().add(const Duration(days: 30)));

  String get fileExtension => filePath.split('.').last.toUpperCase();
}
