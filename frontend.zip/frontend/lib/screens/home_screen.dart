import 'package:flutter/material.dart';
import '../components/document_upload_form.dart';
import '../components/document_list.dart';
import '../components/sort_filter_widget.dart';
import '../models/document_model.dart';
import '../models/priority_model.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Document> _documents = [
    Document(
      name: 'Degree Certificate',
      category: 'Degree',
      filePath: '/docs/degree.pdf',
      uploadedAt: DateTime.now().subtract(const Duration(days: 10)),
      user: 'Smit',
      expiryDate: null,
      groupId: 'education_1',
      priority: DocumentPriority(
        level: PriorityLevel.high,
        isLoved: true,
        customRank: 1,
      ),
    ),
    Document(
      name: 'College Result',
      category: 'Degree',
      filePath: '/docs/result.pdf',
      uploadedAt: DateTime.now().subtract(const Duration(days: 2)),
      user: 'Smit',
      expiryDate: null,
      groupId: 'education_1',
      priority: DocumentPriority(
        level: PriorityLevel.medium,
        customRank: 2,
      ),
    ),
    Document(
      name: 'Medical Report',
      category: 'Medical',
      filePath: '/docs/medical.pdf',
      uploadedAt: DateTime.now().subtract(const Duration(days: 5)),
      user: 'Family',
      expiryDate: DateTime.now().add(const Duration(days: 30)),
      priority: DocumentPriority(
        level: PriorityLevel.critical,
        isLoved: false,
        customRank: 3,
      ),
    ),
    Document(
      name: 'Property Deed',
      category: 'Property',
      filePath: '/docs/property.pdf',
      uploadedAt: DateTime.now().subtract(const Duration(days: 20)),
      user: 'Smit',
      expiryDate: null,
      priority: DocumentPriority(
        level: PriorityLevel.low,
        isLoved: false,
      ),
    ),
    Document(
      name: 'Expired License',
      category: 'Other',
      filePath: '/docs/license.pdf',
      uploadedAt: DateTime.now().subtract(const Duration(days: 100)),
      user: 'Smit',
      expiryDate: DateTime.now().subtract(const Duration(days: 5)),
      priority: DocumentPriority(
        level: PriorityLevel.none,
        isLoved: false,
      ),
    ),
  ];

  // Filter and sort state
  String? _selectedCategory;
  String _searchQuery = '';
  bool _groupDocuments = false;
  SortOption _selectedSortOption = SortOption.newest;

  void _showUploadForm(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          left: 16,
          right: 16,
          top: 24,
        ),
        child: DocumentUploadForm(
          onUpload: (name, category, filePath, user, expiryDate, groupId) {
            setState(() {
              _documents.add(Document(
                name: name,
                category: category,
                filePath: filePath,
                uploadedAt: DateTime.now(),
                user: user,
                expiryDate: expiryDate,
                groupId: groupId,
                priority: DocumentPriority(), // Default priority
              ));
            });
            Navigator.pop(context);
          },
        ),
      ),
    );
  }

  void _updateDocumentPriority(int index, DocumentPriority newPriority) {
    setState(() {
      _documents[index] = _documents[index].copyWith(priority: newPriority);
    });
  }

  List<Document> get _filteredAndSortedDocuments {
    var filtered = _documents;

    // Apply category filter
    if (_selectedCategory != null && _selectedCategory != 'All') {
      filtered = filtered.where((doc) => doc.category == _selectedCategory).toList();
    }

    // Apply search filter
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((doc) =>
        doc.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
        doc.category.toLowerCase().contains(_searchQuery.toLowerCase()) ||
        (doc.user?.toLowerCase().contains(_searchQuery.toLowerCase()) ?? false)
      ).toList();
    }

    // Apply sorting
    switch (_selectedSortOption) {
      case SortOption.newest:
        filtered.sort((a, b) => b.uploadedAt.compareTo(a.uploadedAt));
        break;
      case SortOption.oldest:
        filtered.sort((a, b) => a.uploadedAt.compareTo(b.uploadedAt));
        break;
      case SortOption.alphabetical:
        filtered.sort((a, b) => a.name.compareTo(b.name));
        break;
      case SortOption.priority:
        filtered.sort((a, b) {
          // First sort by priority score (higher score first)
          final scoreComparison = b.priority.priorityScore.compareTo(a.priority.priorityScore);
          if (scoreComparison != 0) return scoreComparison;
          
          // Then by upload date (newer first)
          return b.uploadedAt.compareTo(a.uploadedAt);
        });
        break;
    }

    return filtered;
  }

  List<String> get _categories => [
    'All',
    ...{for (final doc in _documents) doc.category},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Document Manager'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              // TODO: Implement search functionality
            },
          ),
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {
              // TODO: Show expiry notifications
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildStatsCards(),
            const SizedBox(height: 24),
            SortFilterWidget(
              selectedSortOption: _selectedSortOption,
              onSortChanged: (option) => setState(() => _selectedSortOption = option),
              selectedCategory: _selectedCategory,
              categories: _categories,
              onCategoryChanged: (category) => setState(() => _selectedCategory = category),
              searchQuery: _searchQuery,
              onSearchChanged: (query) => setState(() => _searchQuery = query),
              groupDocuments: _groupDocuments,
              onGroupToggle: (group) => setState(() => _groupDocuments = group),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: DocumentList(
                documents: _filteredAndSortedDocuments,
                onPriorityChanged: _updateDocumentPriority,
                groupDocuments: _groupDocuments,
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showUploadForm(context),
        icon: const Icon(Icons.add),
        label: const Text('Upload'),
      ),
    );
  }

  Widget _buildStatsCards() {
    final totalDocs = _documents.length;
    final expiredDocs = _documents.where((doc) => 
      doc.expiryDate != null && doc.expiryDate!.isBefore(DateTime.now())
    ).length;
    final expiringSoon = _documents.where((doc) => 
      doc.expiryDate != null && 
      doc.expiryDate!.isAfter(DateTime.now()) &&
      doc.expiryDate!.isBefore(DateTime.now().add(const Duration(days: 30)))
    ).length;
    final lovedDocs = _documents.where((doc) => doc.priority.isLoved).length;
    final priorityDocs = _documents.where((doc) => doc.priority.hasPriority).length;

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          _buildStatCard(
            title: 'Total Documents',
            value: totalDocs.toString(),
            icon: Icons.folder,
            color: Theme.of(context).primaryColor,
          ),
          const SizedBox(width: 12),
          _buildStatCard(
            title: 'Loved',
            value: lovedDocs.toString(),
            icon: Icons.favorite,
            color: Colors.red,
          ),
          const SizedBox(width: 12),
          _buildStatCard(
            title: 'Priority',
            value: priorityDocs.toString(),
            icon: Icons.star,
            color: Colors.amber,
          ),
          const SizedBox(width: 12),
          _buildStatCard(
            title: 'Expired',
            value: expiredDocs.toString(),
            icon: Icons.warning,
            color: Colors.red,
          ),
          const SizedBox(width: 12),
          _buildStatCard(
            title: 'Expiring Soon',
            value: expiringSoon.toString(),
            icon: Icons.schedule,
            color: Colors.orange,
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              title,
              style: const TextStyle(fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}