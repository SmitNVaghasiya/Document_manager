import 'package:flutter/material.dart';
import '../models/document_model.dart';
import '../models/priority_model.dart';
import 'priority_dialog.dart';

class DocumentList extends StatefulWidget {
  final List<Document> documents;
  final Function(int, DocumentPriority)? onPriorityChanged;
  final bool groupDocuments;

  const DocumentList({
    super.key, 
    required this.documents,
    this.onPriorityChanged,
    this.groupDocuments = false,
  });

  @override
  State<DocumentList> createState() => _DocumentListState();
}

class _DocumentListState extends State<DocumentList> {
  Map<String, List<Document>> get _groupedDocuments {
    if (!widget.groupDocuments) {
      return {'ungrouped': widget.documents};
    }

    final grouped = <String, List<Document>>{};
    for (final doc in widget.documents) {
      final key = doc.groupId ?? doc.name;
      grouped[key] = [...(grouped[key] ?? []), doc];
    }
    return grouped;
  }

  void _showPriorityDialog(Document doc, int index) {
    showDialog(
      context: context,
      builder: (context) => PriorityDialog(
        currentPriority: doc.priority,
        onPriorityChanged: (newPriority) {
          widget.onPriorityChanged?.call(index, newPriority);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return widget.documents.isEmpty
        ? _buildEmptyState()
        : _buildDocumentList();
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.folder_open, size: 64, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text(
            'No documents found',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
          const SizedBox(height: 8),
          Text(
            'Try adjusting your search or filters',
            style: TextStyle(fontSize: 14, color: Colors.grey[500]),
          ),
        ],
      ),
    );
  }

  Widget _buildDocumentList() {
    final grouped = _groupedDocuments;

    return ListView.builder(
      itemCount: grouped.keys.length,
      itemBuilder: (context, index) {
        final groupKey = grouped.keys.elementAt(index);
        final documents = grouped[groupKey]!;

        if (!widget.groupDocuments) {
          return _buildDocumentCard(documents.first, 0);
        }

        return _buildDocumentGroup(groupKey, documents);
      },
    );
  }

  Widget _buildDocumentGroup(String groupKey, List<Document> documents) {
    if (documents.length == 1) {
      final index = widget.documents.indexOf(documents.first);
      return _buildDocumentCard(documents.first, index);
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ExpansionTile(
        leading: CircleAvatar(
          backgroundColor: Theme.of(context).primaryColor.withOpacity(0.1),
          child: Icon(Icons.folder, color: Theme.of(context).primaryColor),
        ),
        title: Text(
          groupKey,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text('${documents.length} documents'),
        children: documents.asMap().entries.map((entry) {
          final index = widget.documents.indexOf(entry.value);
          return _buildDocumentCard(entry.value, index, isGrouped: true);
        }).toList(),
      ),
    );
  }

  Widget _buildDocumentCard(Document doc, int index, {bool isGrouped = false}) {
    return Card(
      margin: isGrouped
          ? const EdgeInsets.symmetric(horizontal: 16, vertical: 4)
          : const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: _getDocumentColor(doc).withOpacity(0.1),
          child: Icon(_getDocumentIcon(doc), color: _getDocumentColor(doc)),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(
                doc.name,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            if (doc.priority.isLoved)
              const Icon(Icons.favorite, color: Colors.red, size: 16),
            if (doc.priority.level != PriorityLevel.none)
              Text(
                doc.priority.level.icon,
                style: const TextStyle(fontSize: 16),
              ),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Category: ${doc.category}'),
            if (doc.user != null) Text('User: ${doc.user}'),
            Text('Uploaded: ${_formatDate(doc.uploadedAt)}'),
            if (doc.expiryDate != null) _buildExpiryText(doc),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (doc.isExpired)
              const Icon(Icons.warning, color: Colors.red, size: 20),
            if (doc.isExpiringSoon)
              const Icon(Icons.schedule, color: Colors.orange, size: 20),
            const SizedBox(width: 8),
            Text(
              doc.fileExtension,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(width: 8),
            IconButton(
              icon: const Icon(Icons.star_border),
              onPressed: () => _showPriorityDialog(doc, index),
              tooltip: 'Set Priority',
            ),
            Icon(Icons.chevron_right, color: Theme.of(context).primaryColor),
          ],
        ),
        onTap: () {
          // TODO: Open document
        },
      ),
    );
  }

  Widget _buildExpiryText(Document doc) {
    if (doc.isExpired) {
      return Text(
        'Expired',
        style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600),
      );
    } else if (doc.isExpiringSoon) {
      return Text(
        'Expires: ${_formatDate(doc.expiryDate!)}',
        style: TextStyle(color: Colors.orange, fontWeight: FontWeight.w600),
      );
    } else {
      return Text(
        'Expires: ${_formatDate(doc.expiryDate!)}',
        style: TextStyle(color: Colors.green, fontWeight: FontWeight.w600),
      );
    }
  }

  Color _getDocumentColor(Document doc) {
    switch (doc.category) {
      case 'Degree':
      case 'Diploma':
      case 'High School':
        return Colors.blue;
      case 'Medical':
        return Colors.red;
      case 'Property':
      case 'Home':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  IconData _getDocumentIcon(Document doc) {
    switch (doc.category) {
      case 'Degree':
      case 'Diploma':
      case 'High School':
        return Icons.school;
      case 'Medical':
        return Icons.local_hospital;
      case 'Property':
      case 'Home':
        return Icons.home;
      default:
        return Icons.insert_drive_file;
    }
  }

  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }
}
